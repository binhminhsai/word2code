import React, { useEffect, useState } from 'react';

const SplitView: React.FC = () => {
  const [logs, setLogs] = useState<string[]>([]);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const steps = [
      'Reading context...',
      'Parsing project structure...',
      'Extracting CSS variables...',
      'Generating React components...',
      'Creating preview canvas...',
      'Finalizing UI states...',
    ];

    let i = 0;
    const interval = setInterval(() => {
      if (i < steps.length) {
        setLogs((prev) => [...prev, `✅ ${steps[i]}`]);
        i += 1;
      } else {
        setDone(true);
        clearInterval(interval);
      }
    }, 900);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex h-[calc(100vh-64px)] overflow-hidden bg-background text-on-surface font-body">
      <section className="w-1/2 bg-[#0D0D0D] text-[#D4D4D4] flex flex-col border-r border-white/10">
        <div className="px-6 py-4 flex items-center justify-between bg-white/[0.03] border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-[#4EC9B0] animate-pulse shadow-[0_0_8px_rgba(78,201,176,0.5)]" />
            <h2 className="font-headline text-lg tracking-tight text-white/90">AI Agent Console</h2>
          </div>
          <div className="flex gap-2">
            <span className="text-xs font-mono text-white/30 px-2 py-1 bg-white/5 rounded border border-white/5">v2.4.0-stable</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 font-mono text-sm space-y-4">
          {logs.length === 0 && <p className="text-white/40">Initializing agent...</p>}
          {logs.map((log, idx) => (
            <div key={idx} className="flex gap-3 items-start animate-in fade-in slide-in-from-left-4 duration-500">
              <span className="material-symbols-outlined text-[#4EC9B0] text-lg" style={{ fontVariationSettings: "'FILL' 1" }}>
                {log.startsWith('✅') ? 'check_circle' : 'sync'}
              </span>
              <div className="space-y-1">
                <p className="text-[#D4D4D4] font-medium">{log}</p>
                <p className="text-[#6A9955] text-xs font-mono">{`// step ${idx + 1} of 6 - completed`}</p>
              </div>
            </div>
          ))}

          <div className="mt-8 p-5 bg-[#1E1E1E] rounded-xl border border-white/10 shadow-2xl">
            <div className="flex items-center gap-2 mb-3 text-white/20 border-b border-white/5 pb-2">
              <span className="material-symbols-outlined text-xs">code_blocks</span>
              <span className="text-[10px] font-mono tracking-widest uppercase">analysis_stream.ts</span>
            </div>
            <pre className="font-mono text-[13px] leading-6 overflow-x-auto">
              <div className="flex">
                <span className="text-[#569cd6]">function</span>&nbsp;
                <span className="text-[#dcdcaa]">applyTheme</span>
                <span className="text-[#D4D4D4]">(</span>
                <span className="text-[#9cdcfe]">themeData</span>
                <span className="text-[#D4D4D4]">) {'{'}</span>
              </div>
              <div className="pl-4">
                <span className="text-[#c586c0]">const</span>&nbsp;
                <span className="text-[#9cdcfe]">tokens</span> = <span className="text-[#9cdcfe]">themeData</span>.tokens;
              </div>
              <div className="pl-4">
                <span className="text-[#9cdcfe]">tokens</span>.
                <span className="text-[#dcdcaa]">forEach</span>(
                <span className="text-[#9cdcfe]">token</span> =&gt; 
                <span className="text-[#dcdcaa]">applyToken</span>(token));
              </div>
              <div className="pl-4">
                <span className="text-[#9cdcfe]">console</span>.
                <span className="text-[#dcdcaa]">log</span>(
                <span className="text-[#ce9178]">'Mapping'</span>, token.name, 
                <span className="text-[#ce9178]">' -&gt; '</span>, token.value);
              </div>
              <div><span className="text-[#D4D4D4]">{'}'}</span></div>
            </pre>
          </div>
        </div>

        <div className="p-4 bg-white/[0.02] border-t border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-4 text-[10px] text-white/30 font-mono tracking-wider">
            <span className="flex items-center gap-1.5"><span className="material-symbols-outlined text-[14px]">terminal</span> SYSTEM_READY</span>
            <span className="flex items-center gap-1.5"><span className="material-symbols-outlined text-[14px]">memory</span> MEM_USAGE: 1.2GB</span>
          </div>
          <div className={`text-[10px] font-bold px-2 py-0.5 rounded border font-mono ${done ? 'text-[#4EC9B0] border-[#4EC9B0]/30' : 'text-primary border-primary/30'}`}>
            {done ? 'STATUS: RESOLVED' : 'STATUS: EXECUTING'}
          </div>
        </div>
      </section>

      <section className="w-1/2 bg-surface-container-low flex flex-col">
        <div className="px-6 py-4 flex items-center justify-between border-b border-outline-variant bg-white/50 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <span className="material-symbols-outlined text-on-surface-variant">visibility</span>
            <h2 className="font-headline text-lg text-on-surface">Live Preview</h2>
          </div>
          <div className="flex items-center gap-2 bg-surface-container p-1 rounded-full border border-outline-variant">
            <button className="px-3 py-1 bg-white shadow-sm rounded-full text-xs font-bold text-primary">Desktop</button>
            <button className="px-3 py-1 text-xs font-bold text-on-surface-variant hover:text-on-surface">Mobile</button>
          </div>
        </div>

        <div className="flex-1 p-8 overflow-y-auto">
          <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-sm overflow-hidden border border-outline-variant min-h-full">
            <div className="p-6 border-b border-outline-variant flex justify-between items-center">
              <div className="w-32 h-6 skeleton-pulse rounded-md" />
              <div className="flex gap-4">
                <div className="w-16 h-4 skeleton-pulse rounded-md" />
                <div className="w-16 h-4 skeleton-pulse rounded-md" />
                <div className="w-16 h-4 skeleton-pulse rounded-md" />
              </div>
            </div>
            <div className="p-12 space-y-6">
              <div className="w-3/4 h-12 skeleton-pulse rounded-lg mx-auto" />
              <div className="w-full h-4 skeleton-pulse rounded-lg" />
              <div className="w-5/6 h-4 skeleton-pulse rounded-lg" />
              <div className="w-40 h-12 skeleton-pulse rounded-full mx-auto mt-8" />
            </div>
            <div className="p-12 grid grid-cols-3 gap-6">
              <div className="col-span-2 h-64 skeleton-pulse rounded-xl" />
              <div className="col-span-1 h-64 skeleton-pulse rounded-xl" />
              <div className="col-span-1 h-64 skeleton-pulse rounded-xl" />
              <div className="col-span-2 h-64 skeleton-pulse rounded-xl" />
            </div>
            <div className="p-12 bg-surface-container mt-12">
              <div className="grid grid-cols-4 gap-8">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="space-y-4">
                    <div className="w-20 h-4 skeleton-pulse rounded-md" />
                    <div className="w-full h-3 skeleton-pulse rounded-sm" />
                    <div className="w-full h-3 skeleton-pulse rounded-sm" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SplitView;
