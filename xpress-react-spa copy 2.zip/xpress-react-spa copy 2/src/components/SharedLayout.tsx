import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';

const SharedLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const stepItems = [
    { label: 'Project management', path: '/app/projects' },
    { label: 'Canvas edit', path: '/app/editor' },
    { label: 'AI Generate', path: '/app/editor/split-view' },
    { label: 'Preview & edit', path: '/app/editor/visual' },
    { label: 'Launch', path: '/app/deploy' },
  ];

  const currentPath = location.pathname;
  const currentStep =
    currentPath.startsWith('/app/deploy') ? 4 :
    currentPath.startsWith('/app/editor/visual') ? 3 :
    currentPath.startsWith('/app/editor/split-view') ? 2 :
    currentPath.startsWith('/app/editor') ? 1 :
    0;

  return (
    <div className="flex flex-col bg-surface text-on-surface font-body antialiased min-h-screen overflow-hidden">
      <header className="sticky top-0 z-50 bg-surface/95 backdrop-blur-md border-b border-outline-variant/30 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-5 py-3">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/')}> 
            <span className="text-xl font-bold text-primary font-headline italic">X-press AI</span>
            <span className="text-sm text-stone-600">Back to landing</span>
          </div>
          <nav className="flex items-center gap-5 text-sm font-medium text-stone-700">
            <NavLink
              to="/app/projects"
              className={({ isActive }) =>
                `px-2 py-1 rounded-md ${isActive ? 'text-primary border-b-2 border-primary font-bold' : 'hover:text-primary'}`
              }
            >
              Home
            </NavLink>
            <a className="px-2 py-1 rounded-md hover:text-primary" href="#">Hosting</a>
            <a className="px-2 py-1 rounded-md hover:text-primary" href="#">Support</a>
          </nav>
        </div>
        <div className="px-8 py-6 bg-[#FAF9F6] border-b border-[#E8E6E1]">
          <div className="flex items-center justify-between mb-4">
            <div className="flex flex-col">
               <h3 className="text-[14px] font-medium text-[#233227]/80">press AI engine into your WordPress site.</h3>
            </div>
            <div className="text-[12px] font-bold text-[#49704F] uppercase tracking-[0.15em]">
              STEP {currentStep + 1} OF {stepItems.length}
            </div>
          </div>

          <div className="relative h-[6px] mb-3">
            <div className="absolute inset-0 w-full h-full rounded-full bg-[#E8E6E1]" />
            <div
              className="absolute top-0 left-0 h-full rounded-full bg-[#49704F] transition-all duration-700 ease-out"
              style={{ width: `${((currentStep + 1) / stepItems.length) * 100}%` }}
            />
          </div>

          <div className="flex justify-between items-start">
            {stepItems.map((step, idx) => (
              <div 
                key={idx} 
                onClick={() => navigate(step.path)}
                className={`text-[11px] font-bold tracking-tight cursor-pointer transition-colors duration-300 ${idx === currentStep ? 'text-[#49704F]' : 'text-[#8E9892] hover:text-[#233227]'}`}
                style={{ width: '18%', textAlign: idx === 0 ? 'left' : idx === stepItems.length - 1 ? 'right' : 'center' }}
              >
                {step.label}
              </div>
            ))}
          </div>
        </div>
      </header>

      <main className="flex-1 pt-4 w-full min-h-[calc(100vh-76px)]">
        <Outlet />
      </main>
    </div>
  );
};

export default SharedLayout;

